from app import app

# This file provides the entry point for Gunicorn
# and exposes our Flask application